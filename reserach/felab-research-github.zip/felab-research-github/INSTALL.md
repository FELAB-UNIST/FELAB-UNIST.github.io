# FE Lab Research page installation

This package is adapted to the existing static routing structure of
`FELAB-UNIST.github.io`. It does not require React, npm, or a build step.

## 1. Copy the four new files

Copy each file into the same relative path in the repository:

| Package file | Repository destination | Purpose |
| --- | --- | --- |
| `pages/research.html` | `pages/research.html` | Research-page HTML fragment |
| `css/research.css` | `css/research.css` | Page-scoped styling and responsive layout |
| `js/modules/research.js` | `js/modules/research.js` | Theme rendering and interactive coauthor network |
| `data/research-config.json` | `data/research-config.json` | Research themes, representative papers, affiliations, and category overrides |

The existing `data/publications.json` remains the source for the complete
coauthor network. Do not copy or duplicate it.

## 2. Load the stylesheet and script in `index.html`

Add the research stylesheet immediately after the existing custom stylesheet:

```html
<link rel="stylesheet" href="./css/styles.css">
<link rel="stylesheet" href="./css/research.css">
```

Add the research module immediately before `./js/app.js`:

```html
<script src="./js/modules/activities.js"></script>
<script src="./js/modules/research.js"></script>
<script src="./js/app.js"></script>
```

## 3. Add the Research tab in `components/header.html`

In the desktop navigation, add:

```html
<a href="#" data-tab="research" class="nav-link text-sm font-medium text-gray-600 hover:text-brand-navy transition-colors">Research</a>
```

In the mobile-menu navigation in the same file, add:

```html
<a href="#" data-tab="research" class="nav-link block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-brand-navy hover:bg-gray-50">Research</a>
```

Placing Research between Publications and Projects keeps the desktop and mobile
orders consistent.

## 4. Initialize the page in `js/app.js`

Add the page title to the `titles` object inside `loadPage`:

```js
'publications': 'Publications',
'research': 'Research',
'projects': 'Research Projects',
```

Add this case inside `initializePage(page)`:

```js
case 'research':
    if (typeof ResearchManager !== 'undefined') {
        ResearchManager.init();
    }
    break;
```

No additional route table is needed. The existing router already loads
`./pages/${page}.html`, so the new tab automatically resolves to
`pages/research.html`.

## 5. Apply the changes

You can make the three existing-file edits manually using the snippets above,
or place `integration.patch` in the repository root and run:

```bash
git apply integration.patch
```

Then commit the four new files together with the three edited files.

## Resulting URL

After GitHub Pages updates, the page will be available at:

```text
https://felab-unist.github.io/#research
```

Do not link directly to `/pages/research.html`; that file is an HTML fragment
designed to be loaded inside the site's shared header, footer, and router.

## Updating the page later

- Add, remove, or edit publications in `data/publications.json`. The coauthor
  network will update automatically.
- Edit representative papers and research descriptions in
  `data/research-config.json`.
- Update author affiliations and group membership in the `affiliations` and
  `authorGroups` objects in `data/research-config.json`.
- Use `classificationOverrides` when a paper is assigned to the wrong research
  area by the keyword rules.
- Working papers are excluded automatically.
- Only authors appearing in at least two included publications are shown.
- The author detail panel displays at most five paper titles.

## Files that do not need modification

- `components/drawer.html`: this is a publication/profile detail drawer, not
  the mobile navigation.
- `data/publications.json`: it is already read directly by the research page.
- `css/styles.css`: research styles are isolated in `css/research.css` to reduce
  style conflicts.
