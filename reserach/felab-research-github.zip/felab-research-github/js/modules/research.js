// Research page and publication-driven coauthor network
const ResearchManager = {
    config: null,
    publications: [],
    graph: { nodes: [], links: [] },
    area: 'all',
    selectedAuthor: 'yongjae-lee',

    categoryLabels: {
        all: 'All publications',
        llms: 'LLMs in Finance',
        decisions: 'Investment Decision Making',
        assets: 'Financial Asset Modeling',
        investors: 'Investor Modeling',
        other: 'Other'
    },

    async init() {
        const page = document.getElementById('research-page');
        if (!page) return;

        this.setupSectionLinks(page);

        try {
            const [configResponse, publicationResponse] = await Promise.all([
                fetch('./data/research-config.json', { cache: 'no-store' }),
                fetch('./data/publications.json', { cache: 'no-store' })
            ]);

            if (!configResponse.ok || !publicationResponse.ok) {
                throw new Error('Research data could not be loaded.');
            }

            this.config = await configResponse.json();
            const publicationData = await publicationResponse.json();
            this.publications = (publicationData.publications || [])
                .filter((publication) => !this.isWorkingPaper(publication))
                .map((publication) => ({
                    ...publication,
                    category: this.classifyPublication(publication)
                }));

            this.renderThemes();
            this.renderReviews();
            this.graph = this.buildGraph(this.publications);
            this.renderNetwork();
        } catch (error) {
            console.error('Research page initialization failed:', error);
            const networkRoot = document.getElementById('research-network-root');
            if (networkRoot) {
                networkRoot.className = 'research-network-shell research-network-state';
                networkRoot.innerHTML = '<strong>Research data is temporarily unavailable.</strong> Please try again later.';
            }
        }
    },

    setupSectionLinks(page) {
        page.addEventListener('click', (event) => {
            const link = event.target.closest('a[href^="#research-"]');
            if (!link) return;
            const target = document.querySelector(link.getAttribute('href'));
            if (!target) return;
            event.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    },

    isWorkingPaper(publication) {
        const fields = [publication.year, publication.type, publication.venue, publication.notes]
            .filter(Boolean)
            .join(' ')
            .toLowerCase();
        return /working\s*paper/.test(fields) || String(publication.year).toLowerCase() === 'working';
    },

    classifyPublication(publication) {
        const title = String(publication.title || '').trim();
        const overrides = this.config.classificationOverrides || {};
        for (const category of ['other', 'decisions', 'assets', 'llms', 'investors']) {
            if ((overrides[category] || []).includes(title)) return category;
        }

        const searchable = `${title} ${(publication.keywords || []).join(' ')}`.toLowerCase();
        if (/household|individual investor|retail investor|couples|personalized|goal-based|financial sustainability|investor modeling|investor taxonomy|taxonomy of retail|recommender|recommendation|high-cost patients|disease-specific|\bnft\b/.test(searchable)) return 'investors';
        if (/\bllms?\b|large language model|agentic retrieval|financial security knowledge|guruagents|forecasting future language/.test(searchable)) return 'llms';
        if (/decision-focused|decision by supervised|portfolio optimization|portfolio selection|asset allocation|financial planning|mean-variance|stochastic programming|stochastic goal|sparse tangent|market making|index tracking|option to postpone a goal/.test(searchable)) return 'decisions';
        return 'assets';
    },

    renderThemes() {
        const root = document.getElementById('research-theme-sections');
        if (!root) return;
        root.innerHTML = this.config.themes.map((theme) => `
            <section class="research-theme-section" id="research-${this.escape(theme.id)}">
                <div class="research-theme-header">
                    <div class="research-theme-number">${this.escape(theme.index)}</div>
                    <div>
                        <p class="research-theme-label">Research area</p>
                        <h2>${this.escape(theme.title)}</h2>
                        <p class="research-theme-statement">${this.escape(theme.statement)}</p>
                    </div>
                    <p class="research-theme-description">${this.escape(theme.description)}</p>
                </div>
                <div class="research-subtheme-list">
                    ${theme.subthemes.map((subtheme, index) => `
                        <article class="research-subtheme-card">
                            <div class="research-subtheme-number">${this.escape(theme.index)}.${index + 1}</div>
                            <h3>${this.escape(subtheme.title)}</h3>
                            <p>${this.escape(subtheme.description)}</p>
                            ${this.paperList(subtheme.papers)}
                        </article>
                    `).join('')}
                </div>
            </section>
        `).join('');
    },

    renderReviews() {
        const root = document.getElementById('research-review-columns');
        if (!root) return;
        root.innerHTML = this.config.reviews.map((group) => `
            <article>
                <h3>${this.escape(group.group)}</h3>
                ${this.paperList(group.papers)}
            </article>
        `).join('');
    },

    paperList(papers) {
        return `<ul class="research-paper-list">${papers.map((paper) => `
            <li>
                <div>
                    <span>${this.escape(paper.venue)} · ${this.escape(paper.year)}</span>
                    <strong>${this.escape(paper.title)}</strong>
                </div>
                ${paper.link
                    ? `<a href="${this.escapeAttribute(paper.link)}" target="_blank" rel="noopener noreferrer" aria-label="Open ${this.escapeAttribute(paper.title)}">&#8594;</a>`
                    : '<i aria-hidden="true">—</i>'}
            </li>
        `).join('')}</ul>`;
    },

    cleanAuthor(name) {
        const cleaned = name.replace(/[†*‡]/g, '').replace(/\s+/g, ' ').trim();
        return cleaned === 'Hyeongwoo Kong' ? 'Hyungwoo Kong' : cleaned;
    },

    authorId(name) {
        return name.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    },

    parseAuthors(publication) {
        return String(publication.authors || '').split(',').map((name) => this.cleanAuthor(name)).filter(Boolean);
    },

    buildGraph(publications) {
        const paperMap = new Map();
        const areaMap = new Map();
        const displayNames = new Map();
        const linkMap = new Map();
        const labIds = new Set(publications.flatMap((publication) => publication.author_ids || []));

        publications.forEach((publication) => {
            const authors = [...new Set(this.parseAuthors(publication))];
            authors.forEach((name) => {
                const id = this.authorId(name);
                displayNames.set(id, name);
                paperMap.set(id, [...(paperMap.get(id) || []), publication]);
                if (!areaMap.has(id)) areaMap.set(id, new Set());
                areaMap.get(id).add(publication.category);
            });

            for (let i = 0; i < authors.length; i += 1) {
                for (let j = i + 1; j < authors.length; j += 1) {
                    const ids = [this.authorId(authors[i]), this.authorId(authors[j])].sort();
                    const key = ids.join('::');
                    const existing = linkMap.get(key) || { from: ids[0], to: ids[1], papers: [], areas: new Set() };
                    existing.papers.push(publication);
                    existing.areas.add(publication.category);
                    linkMap.set(key, existing);
                }
            }
        });

        const groups = this.config.authorGroups || {};
        const alumni = new Set(groups.alumni || []);
        const linqalpha = new Set(groups.linqalpha || []);
        const external = new Set(groups.external || []);

        const nodeInput = [...paperMap.entries()].map(([id, papers]) => {
            const name = displayNames.get(id);
            const slug = id === 'hyeongwoo-kong' ? 'hyungwoo-kong' : id;
            let type = 'external';
            if (name === 'Yongjae Lee') type = 'pi';
            else if (linqalpha.has(name)) type = 'linqalpha';
            else if (alumni.has(name)) type = 'alumni';
            else if (external.has(name)) type = 'external';
            else if (labIds.has(slug)) type = 'lab';

            return {
                id,
                name,
                affiliation: (this.config.affiliations || {})[name] || (type === 'lab' || type === 'pi' ? 'UNIST' : type === 'linqalpha' ? 'LinqAlpha' : 'External'),
                type,
                papers,
                areas: [...areaMap.get(id)]
            };
        }).filter((node) => node.papers.length >= 2);

        const nodes = this.positionNodes(nodeInput);
        const included = new Set(nodes.map((node) => node.id));
        const links = [...linkMap.values()]
            .filter((link) => included.has(link.from) && included.has(link.to))
            .map((link) => ({ ...link, areas: [...link.areas] }));

        return { nodes, links };
    },

    positionNodes(nodes) {
        const centerX = 500;
        const centerY = 410;
        const pi = nodes.find((node) => node.name === 'Yongjae Lee');
        const rest = nodes
            .filter((node) => node.name !== 'Yongjae Lee')
            .sort((a, b) => b.papers.length - a.papers.length || a.name.localeCompare(b.name));
        const positioned = pi ? [{ ...pi, x: centerX, y: centerY }] : [];
        const rings = [
            { capacity: 14, radiusX: 128, radiusY: 108 },
            { capacity: 22, radiusX: 222, radiusY: 184 },
            { capacity: 32, radiusX: 318, radiusY: 260 },
            { capacity: 40, radiusX: 408, radiusY: 332 },
            { capacity: 50, radiusX: 474, radiusY: 382 }
        ];
        let cursor = 0;
        rings.forEach((ring, ringIndex) => {
            const count = Math.min(ring.capacity, rest.length - cursor);
            for (let index = 0; index < count; index += 1) {
                const node = rest[cursor + index];
                const angle = -Math.PI / 2 + (Math.PI * 2 * index) / count + ringIndex * 0.17;
                positioned.push({
                    ...node,
                    x: centerX + Math.cos(angle) * ring.radiusX,
                    y: centerY + Math.sin(angle) * ring.radiusY
                });
            }
            cursor += count;
        });
        return positioned;
    },

    renderNetwork() {
        const root = document.getElementById('research-network-root');
        if (!root) return;
        root.className = 'research-network-shell';
        root.innerHTML = `
            <div class="research-network-toolbar">
                <div class="research-network-filters" role="group" aria-label="Filter coauthors by research area"></div>
                <div class="research-network-legend">
                    <span><i class="dot lab"></i>FE Lab</span>
                    <span><i class="dot alumni"></i>Alumni</span>
                    <span><i class="dot linqalpha"></i>LinqAlpha</span>
                    <span><i class="dot external"></i>External</span>
                </div>
            </div>
            <div class="research-network-grid">
                <div class="research-network-canvas">
                    <svg viewBox="0 0 1000 820" role="img" aria-label="Interactive coauthor network"></svg>
                    <div class="research-network-note">The network includes coauthors with two or more publications in the lab's complete publication data. Select any node for details.</div>
                </div>
                <aside class="research-network-detail" aria-live="polite"></aside>
            </div>
            <p class="research-network-source"></p>
        `;

        root.querySelector('.research-network-filters').addEventListener('click', (event) => {
            const button = event.target.closest('button[data-area]');
            if (!button) return;
            this.area = button.dataset.area;
            this.updateNetwork();
        });

        root.querySelector('svg').addEventListener('click', (event) => {
            const node = event.target.closest('[data-author-id]');
            if (!node || node.classList.contains('muted')) return;
            this.selectedAuthor = node.dataset.authorId;
            this.updateNetwork();
        });

        root.querySelector('svg').addEventListener('keydown', (event) => {
            if (event.key !== 'Enter' && event.key !== ' ') return;
            const node = event.target.closest('[data-author-id]');
            if (!node || node.classList.contains('muted')) return;
            event.preventDefault();
            this.selectedAuthor = node.dataset.authorId;
            this.updateNetwork();
        });

        root.querySelector('.research-network-detail').addEventListener('click', (event) => {
            const button = event.target.closest('button[data-area]');
            if (!button) return;
            this.area = button.dataset.area;
            this.updateNetwork();
        });

        this.updateNetwork();
    },

    updateNetwork() {
        const root = document.getElementById('research-network-root');
        if (!root) return;
        const counts = this.publications.reduce((result, paper) => {
            result[paper.category] = (result[paper.category] || 0) + 1;
            return result;
        }, {});

        const filters = root.querySelector('.research-network-filters');
        filters.innerHTML = Object.keys(this.categoryLabels).map((id) => `
            <button type="button" data-area="${id}" class="${this.area === id ? 'selected' : ''}">
                ${this.escape(this.categoryLabels[id])}
                <span>${id === 'all' ? this.publications.length : (counts[id] || 0)}</span>
            </button>
        `).join('');

        const nodeById = new Map(this.graph.nodes.map((node) => [node.id, node]));
        let selectedNode = nodeById.get(this.selectedAuthor) || this.graph.nodes.find((node) => node.name === 'Yongjae Lee') || this.graph.nodes[0];
        if (selectedNode) this.selectedAuthor = selectedNode.id;

        const activePaperIds = new Set(this.publications
            .filter((paper) => this.area === 'all' || paper.category === this.area)
            .map((paper) => `${paper.title}-${paper.year}`));
        const activeIds = new Set(this.graph.nodes
            .filter((node) => node.papers.some((paper) => activePaperIds.has(`${paper.title}-${paper.year}`)))
            .map((node) => node.id));
        const topLabels = new Set(this.graph.nodes.slice()
            .sort((a, b) => b.papers.length - a.papers.length)
            .slice(0, 22)
            .map((node) => node.id));

        const linksMarkup = this.graph.links.map((link) => {
            const from = nodeById.get(link.from);
            const to = nodeById.get(link.to);
            const activeCount = link.papers.filter((paper) => this.area === 'all' || paper.category === this.area).length;
            const connected = selectedNode && (link.from === selectedNode.id || link.to === selectedNode.id);
            const className = activeCount ? (connected ? 'selected-link' : 'active') : 'muted';
            const width = activeCount ? Math.min(5, 0.35 + activeCount * 0.55) : 0.3;
            return `<line x1="${from.x}" y1="${from.y}" x2="${to.x}" y2="${to.y}" class="${className}" stroke-width="${width}"></line>`;
        }).join('');

        const nodesMarkup = this.graph.nodes.map((node) => {
            const active = activeIds.has(node.id);
            const chosen = selectedNode && selectedNode.id === node.id;
            const filteredCount = node.papers.filter((paper) => this.area === 'all' || paper.category === this.area).length;
            const radius = node.type === 'pi' ? 24 : Math.min(15, 4.5 + Math.sqrt(filteredCount || node.papers.length) * 2.1);
            const showLabel = chosen || topLabels.has(node.id);
            return `
                <g class="research-network-node ${node.type} ${active ? 'active' : 'muted'} ${chosen ? 'chosen' : ''}"
                   data-author-id="${this.escapeAttribute(node.id)}" role="button" tabindex="${active ? 0 : -1}"
                   aria-label="${this.escapeAttribute(`${node.name}, ${node.affiliation}, ${filteredCount} publications in this view`)}">
                    <circle cx="${node.x}" cy="${node.y}" r="${radius + 7}" class="node-halo"></circle>
                    <circle cx="${node.x}" cy="${node.y}" r="${radius}" class="node-circle"></circle>
                    ${showLabel ? `
                        <text x="${node.x}" y="${node.y + radius + 15}" text-anchor="middle" class="node-label">${this.escape(node.name)}</text>
                        <text x="${node.x}" y="${node.y + radius + 26}" text-anchor="middle" class="node-affiliation">${this.escape(node.affiliation)}</text>
                    ` : ''}
                    ${node.type === 'pi' ? `<text x="${node.x}" y="${node.y + 4}" text-anchor="middle" class="pi-label">PI</text>` : ''}
                </g>
            `;
        }).join('');

        root.querySelector('svg').innerHTML = `<g class="research-network-links">${linksMarkup}</g><g>${nodesMarkup}</g>`;
        root.querySelector('svg').setAttribute('aria-label', `Interactive coauthor network built from ${activePaperIds.size} publications`);

        if (selectedNode) this.renderNetworkDetail(root, selectedNode);

        root.querySelector('.research-network-source').innerHTML = `
            <strong>${this.publications.length} publications · ${this.graph.nodes.length} recurring authors · ${this.graph.links.length} coauthor connections.</strong>
            Authors are shown after appearing in at least two publications. The network reads directly from FE Lab's
            <a href="./data/publications.json" target="_blank" rel="noopener noreferrer">publications.json</a>, so newly added records are incorporated automatically.
        `;
    },

    renderNetworkDetail(root, node) {
        const selectedPapers = node.papers
            .filter((paper) => this.area === 'all' || paper.category === this.area)
            .sort((a, b) => String(b.year).localeCompare(String(a.year)));
        const collaborators = new Set(this.graph.links
            .filter((link) => link.from === node.id || link.to === node.id)
            .flatMap((link) => [link.from, link.to])
            .filter((id) => id !== node.id)).size;

        root.querySelector('.research-network-detail').innerHTML = `
            <p class="research-detail-kicker">Selected collaborator</p>
            <h3>${this.escape(node.name)}</h3>
            <p class="research-detail-affiliation">${this.escape(node.affiliation)}</p>
            <div class="research-detail-stats">
                <div><strong>${selectedPapers.length}</strong><span>${this.area === 'all' ? 'total publications' : 'papers in this area'}</span></div>
                <div><strong>${collaborators}</strong><span>direct coauthors</span></div>
            </div>
            <div class="research-detail-areas">
                <span>Research connections</span>
                <div>${node.areas.map((id) => `<button type="button" data-area="${id}">${this.escape(this.categoryLabels[id])}</button>`).join('')}</div>
            </div>
            <div class="research-detail-papers">
                <span>${this.escape(this.area === 'all' ? 'Publications' : this.categoryLabels[this.area])}</span>
                <ul>${selectedPapers.slice(0, 5).map((paper) => `
                    <li>
                        <small>${this.escape(paper.year)} · ${this.escape(this.categoryLabels[paper.category])}</small>
                        ${paper.link
                            ? `<a href="${this.escapeAttribute(paper.link)}" target="_blank" rel="noopener noreferrer">${this.escape(paper.title)}</a>`
                            : this.escape(paper.title)}
                    </li>
                `).join('')}</ul>
                ${selectedPapers.length > 5 ? `<p class="research-detail-more">+ ${selectedPapers.length - 5} more publications</p>` : ''}
            </div>
        `;
    },

    escape(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    },

    escapeAttribute(value) {
        return this.escape(value);
    }
};

window.ResearchManager = ResearchManager;
